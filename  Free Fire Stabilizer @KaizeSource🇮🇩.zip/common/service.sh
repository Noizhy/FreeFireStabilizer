#!/system/bin/sh

# # #  S e r v i c e  .  s h  -  F r e e  F i r e  S t a b i l i z e r # # #
# Created By @KaizeSource a.k.a Kaize Team
# Published on Telegram on 13 - 2 - 2024



# Please Remember, always to give us a credit if you want to use our code.
# And also, if we do not found who made the script code that included in here, please let us know by dm-ing us so that we can correct it and give a credit to them.

rm -rf /data/media/0/Android/🇮🇩KaizeModules🇮🇩
mkdir /data/media/0/Android/🇮🇩KaizeModules🇮🇩

check_file() {
  if [[ -f "$1" ]]; then
    return 0
  else
    return 1
  fi
}

read_file_unlock() {
  if check_file "$1"; then
    chmod 444 "$1"
    cat "$1"
    chmod 644 "$1"  
  fi
}

write_file_lock() {
  if check_file "$1"; then
    chmod 644 "$1"  
    echo "$2" > "$1"
    chmod 444 "$1"
  fi
}

error() {
    local error_message="$1"
    local log_path="/data/media/0/Android/🇮🇩KaizeModules🇮🇩/FreeFire-Kaize.log"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - ERROR: $error_message" >> "$log_path"
}

twk() {
    local success_message="$1"
    local log_path="/data/media/0/Android/🇮🇩KaizeModules🇮🇩/FreeFire-Kaize.log"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - SUCCESS: $success_message" >> "$log_path"
}

msg() {
    local msg="$1"
    local log_path="/data/media/0/Android/🇮🇩KaizeModules🇮🇩/FreeFire-Kaize.log"
    echo "$msg" >> "$log_path"
}

# Apply MTK MOD Optimization
nohup sh $MODDIR/script/optimization.sh > /dev/null &
sleep 10

# Apply @KaizeSource Tweaks
msg "starting.."
msg ""
msg " Disabling msm thermal feature" # Credit to @KaizeSource
find /sys -name enabled | grep 'msm_thermal' | while IFS= read -r msm_thermal_status; do
  if [ "$(cat "$msm_thermal_status")" = 'Y' ]; then
    echo 'N' > "$msm_thermal_status"
    twk "Thermal status set to 'N' successfully."
  elif [ "$(cat "$msm_thermal_status")" = '1' ]; then
    echo '0' > "$msm_thermal_status"
    twk "Thermal status set to '0' successfully."
  else
    error "Failed to set thermal status."
  fi
done

msg ""
msg "#######################################################"
msg " Disabling Thermal" # Credit to @KaizeSourc
setprop init.svc.thermal stopped && twk "Set init.svc.thermal to stopped" || error "Failed to set init.svc.thermal"
setprop init.svc.thermal-managers stopped && twk "Set init.svc.thermal-managers to stopped" || error "Failed to set init.svc.thermal-managers"
setprop init.svc.thermal_manager stopped && twk "Set init.svc.thermal_manager to stopped" || error "Failed to set init.svc.thermal_manager"
setprop init.svc.thermal_mnt_hal_service stopped && twk "Set init.svc.thermal_mnt_hal_service to stopped" || error "Failed to set init.svc.thermal_mnt_hal_service"
setprop init.svc.thermal-engine stopped && twk "Set init.svc.thermal-engine to stopped" || error "Failed to set init.svc.thermal-engine"
setprop init.svc.mi-thermald stopped && twk "Set init.svc.mi-thermald to stopped" || error "Failed to set init.svc.mi-thermald"
setprop init.svc.thermalloadalgod stopped && twk "Set init.svc.thermalloadalgod to stopped" || error "Failed to set init.svc.thermalloadalgod"
setprop init.svc.thermalservice stopped && twk "Set init.svc.thermalservice to stopped" || error "Failed to set init.svc.thermalservice"
setprop init.svc.thermal-hal stopped && twk "Set init.svc.thermal-hal to stopped" || error "Failed to set init.svc.thermal-hal"
setprop init.svc.vendor.thermal-symlinks stopped && twk "Set init.svc.vendor.thermal-symlinks to stopped" || error "Failed to set init.svc.vendor.thermal-symlinks"
setprop init.svc.android.thermal-hal stopped && twk "Set init.svc.android.thermal-hal to stopped" || error "Failed to set init.svc.android.thermal-hal"
setprop init.svc.vendor.thermal-hal stopped && twk "Set init.svc.vendor.thermal-hal to stopped" || error "Failed to set init.svc.vendor.thermal-hal"
setprop init.svc.thermal-manager stopped && twk "Set init.svc.thermal-manager to stopped" || error "Failed to set init.svc.thermal-manager"
setprop init.svc.vendor-thermal-hal-1-0 stopped && twk "Set init.svc.vendor-thermal-hal-1-0 to stopped" || error "Failed to set init.svc.vendor-thermal-hal-1-0"
setprop init.svc.vendor.thermal-hal-1-0 stopped && twk "Set init.svc.vendor.thermal-hal-1-0 to stopped" || error "Failed to set init.svc.vendor.thermal-hal-1-0"
setprop init.svc.vendor.thermal-hal-2-0.mtk stopped && twk "Set init.svc.vendor.thermal-hal-2-0.mtk to stopped" || error "Failed to set init.svc.vendor.thermal-hal-2-0.mtk"
setprop init.svc.vendor.thermal-hal-2-0 stopped && twk "Set init.svc.vendor.thermal-hal-2-0 to stopped" || error "Failed to set init.svc.vendor.thermal-hal-2-0"
setprop init.svc.android.thermal-hal stopped && twk "Set init.svc.android.thermal-hal to stopped" || error "Failed to set init.svc.android.thermal-hal"

msg ""
msg "#######################################################"
msg " Disabling Thermal #1 and Logs #2 " # Credit to @KaizeSource
stop log && twk "Stopped log" || error "Failed to stop log"
stop logd && twk "Stopped logd" || error "Failed to stop logd"
stop statsd && twk "Stopped statsd" || error "Failed to stop statsd"
stop stats && twk "Stopped stats" || error "Failed to stop stats"
stop perf && twk "Stopped perf" || error "Failed to stop perf"
stop tracing && twk "Stopped tracing" || error "Failed to stop tracing"
stop trace && twk "Stopped trace" || error "Failed to stop trace"
stop perfd && twk "Stopped perfd" || error "Failed to stop perfd"
stop statscompanion && twk "Stopped statscompanion" || error "Failed to stop statscompanion"

msg ""
msg "#######################################################"
msg " Disabling Thermal Shit" # Credit to azazil
for thermal in $(resetprop | awk -F '[][]' '/thermal/ {print $2}'); do
  if [[ $(resetprop "$thermal") == "running" || $(resetprop "$thermal") == "restarting" ]]; then
    
    stop "${thermal/init.svc.thermalloadalgod}"
    stop "${thermal/init.svc.vendor-}"
    stop "${thermal/init.svc.vendor.}"
    stop "${thermal/init.thermal_}"
    stop "${thermal/init.svc.}"
    
    sleep 10
    
    resetprop -n "$thermal" stopped
    
    if [[ $? -eq 0 ]]; then
      twk "Stopped $thermal successfully."
    else
      error "Failed to stop $thermal."
    fi
  fi
done

msg ""
msg "#######################################################"
msg " Setting scheduler to noop" # Credit to @KaizeSource
for i in /sys/block/*/queue/scheduler; do
  echo "noop" > "$i" && twk "Scheduler set to 'noop' for $i successfully." || error "Failed to set scheduler to 'noop' for $i."
done

#######################################################

msg ""
msg "#######################################################"
msg " Applying Free Fire Tweak" # Credit to @KaizeSource
package_name="com.dts.freefireth"

result=$(cmd package compile -m speed com.dts.freefireth)

if [[ $? -eq 0 ]]; then
    twk "Successfully compiled Free Fire"
else
    error "Failed to compile Freefire. Error: $result"
fi

result=$(settings put global heads_up_notifications_disabled_package_list "$package_name")
if [[ $? -eq 0 ]]; then
    twk "Successfully disabled heads-up notifications for $package_name"
else
    error "Failed to disable heads-up notifications for $package_name. Error: $result"
fi

result=$(cmd game mode performance "$package_name")

if [[ $? -eq 0 ]]; then 
    twk "Successfully set game mode to performance for $package_name"
else
    error "Failed to set game mode to performance for $package_name. Error: $result"
fi

msg ""
msg " Setting Governor to perf" # Credit to @KaizeSource
for cpu_policy in /sys/devices/system/cpu/cpufreq/policy*; do
    chmod 0644 "$cpu_policy/scaling_governor"
    restorecon -R "$cpu_policy"
    if [[ -e "$cpu_policy/scaling_governor" ]]; then
        echo "performance" > "$cpu_policy/scaling_governor" && twk "Successfully set scaling_governor for $cpu_policy" || error "Failed to set scaling_governor for $cpu_policy"
    else
        error "scaling_governor not found for $cpu_policy"
    fi
done

#######################################################

msg ""
msg "#######################################################"
msg " Applying ram tweak"
echo 3 > /proc/sys/vm/drop_caches && twk "drop_caches set to 3 successfully." || error "Failed to set drop_caches to 3."
echo 0 > /proc/sys/vm/page-cluster && twk "page-cluster set to 0 successfully." || error "Failed to set page-cluster to 0."
echo 10 > /proc/sys/vm/dirty_ratio && twk "dirty_ratio set to 10 successfully." || error "Failed to set dirty_ratio to 10."
echo 20 > /proc/sys/vm/dirty_background_ratio && twk "Set dirty_background_ratio to 20" || error "Failed to set dirty_background_ratio"
echo 1000 > /proc/sys/vm/dirty_writeback_centisecs && twk "Set dirty_writeback_centisecs to 1000" || error "Failed to set dirty_writeback_centisecs"
echo 6000 > /proc/sys/vm/dirty_expire_centisecs && twk "Set dirty_expire_centisecs to 6000" || error "Failed to set dirty_expire_centisecs"
echo 0 > /proc/sys/vm/min_free_kbytes && twk "Set min_free_kbytes to 0" || error "Failed to set min_free_kbytes"
echo 0 > /proc/sys/vm/extra_free_kbytes && twk "Set extra_free_kbytes to 0" || error "Failed to set extra_free_kbytes"
echo 1 > /proc/sys/vm/oom_kill_allocating_task && twk "Set oom_kill_allocating_task to 1" || error "Failed to set oom_kill_allocating_task"
echo 100 > /proc/sys/vm/overcommit_ratio && twk "Set overcommit_ratio to 100" || error "Failed to set overcommit_ratio"
echo 0 > /proc/sys/vm/laptop_mode && twk "Set laptop_mode to 0" || error "Failed to set laptop_mode"
echo 200 > /proc/sys/vm/vfs_cache_pressure && twk "Set vfs_cache_pressure to 200" || error "Failed to set vfs_cache_pressure"

#######################################################

msg ""
msg " Deleting Cache" # We do not found who create this script , but, big thanks, shoutout and credit to the person who made it
rm -rf /dev/log/* && twk "Removed contents of /dev/log" || error "Failed to remove contents of /dev/log"
rm -rf /data/log_other_mode/* && twk "Removed contents of /data/log_other_mode" || error "Failed to remove contents of /data/log_other_mode"
rm -rf /sys/kernel/debug/* && twk "Removed contents of /sys/kernel/debug" || error "Failed to remove contents of /sys/kernel/debug"
rm -Rf /cache/*.apk && twk "Removed APK files in /cache" || error "Failed to remove APK files in /cache"
rm -rf /data/log && twk "Removed contents of /data/log" || error "Failed to remove contents of /data/log"
rm -f /data/*.log && twk "Removed .log files in /data" || error "Failed to remove .log files in /data"
rm -f /data/*.txt && twk "Removed .txt files in /data" || error "Failed to remove .txt files in /data"
rm -f /data/anr/* && twk "Removed contents of /data/anr" || error "Failed to remove contents of /data/anr"
rm -f /data/backup/pending/*.tmp && twk "Removed .tmp files in /data/backup/pending" || error "Failed to remove .tmp files in /data/backup/pending"
rm -f /data/cache/*.* && twk "Deleted files in /data/cache" || error "Failed to delete files in /data/cache"
rm -f /data/data/*.log && twk "Deleted .log files in /data/data" || error "Failed to delete .log files in /data/data"
rm -f /data/data/*.txt && twk "Deleted .txt files in /data/data" || error "Failed to delete .txt files in /data/data"
rm -f /data/log/*.log && twk "Deleted .log files in /data/log" || error "Failed to delete .log files in /data/log"
rm -f /data/log/*.txt && twk "Deleted .txt files in /data/log" || error "Failed to delete .txt files in /data/log"
rm -f /data/local/*.apk && twk "Deleted .apk files in /data/local" || error "Failed to delete .apk files in /data/local"
rm -f /data/local/*.log && twk "Deleted .log files in /data/local" || error "Failed to delete .log files in /data/local"
rm -f /data/local/*.txt && twk "Deleted .txt files in /data/local" || error "Failed to delete .txt files in /data/local"
rm -f /data/local/tmp/* && twk "Deleted files in /data/local/tmp" || error "Failed to delete files in /data/local/tmp"
rm -f /data/last_alog/*.log && twk "Deleted .log files in /data/last_alog" || error "Failed to delete .log files in /data/last_alog"
rm -f /data/last_alog/*.txt && twk "Deleted .txt files in /data/last_alog" || error "Failed to delete .txt files in /data/last_alog"
rm -f /data/last_kmsg/*.log && twk "Deleted .log files in /data/last_kmsg" || error "Failed to delete .log files in /data/last_kmsg"
rm -f /data/last_kmsg/*.txt && twk "Deleted last_kmsg files" || error "Failed to delete last_kmsg files"
rm -f /data/mlog/* && twk "Deleted mlog files" || error "Failed to delete mlog files"
rm -f /data/system/*.log && twk "Deleted system log files" || error "Failed to delete system log files"
rm -f /data/system/*.txt && twk "Deleted system text files" || error "Failed to delete system text files"
rm -f /data/system/dropbox/* && twk "Deleted dropbox files" || error "Failed to delete dropbox files"
rm -Rf /data/system/usagestats/* && twk "Deleted usagestats files" || error "Failed to delete usagestats files"
rm -f /data/system/shared_prefs/* && twk "Deleted shared_prefs files" || error "Failed to delete shared_prefs files"
rm -f /data/tombstones/* && twk "Deleted tombstones files" || error "Failed to delete tombstones files"
rm -Rf /sdcard/LOST.DIR && twk "Deleted LOST.DIR directory" || error "Failed to delete LOST.DIR directory"
rm -Rf /sdcard/found000 && twk "Deleted found000 directory" || error "Failed to delete found000 directory"
rm -Rf /sdcard/LazyList && twk "Removed LazyList" || error "Failed to remove LazyList"
rm -Rf /sdcard/albumthumbs && twk "Removed albumthumbs" || error "Failed to remove albumthumbs"
rm -Rf /sdcard/kunlun && twk "Removed kunlun" || error "Failed to remove kunlun"
rm -Rf /sdcard/.CacheOfEUI && twk "Removed .CacheOfEUI" || error "Failed to remove .CacheOfEUI"
rm -Rf /sdcard/.bstats && twk "Removed .bstats" || error "Failed to remove .bstats"
rm -Rf /sdcard/.taobao && twk "Removed .taobao" || error "Failed to remove .taobao"
rm -Rf /sdcard/Backucup && twk "Removed Backucup" || error "Failed to remove Backucup"
rm -Rf /sdcard/MIUI/debug_log && twk "Removed MIUI/debug_log" || error "Failed to remove MIUI/debug_log"
rm -Rf /sdcard/wlan_logs && twk "Removed wlan_logs" || error "Failed to remove wlan_logs"
rm -Rf /sdcard/ramdump && twk "Removed ramdump" || error "Failed to remove ramdump"
rm -Rf /sdcard/UnityAdsVideoCache && twk "Removed UnityAdsVideoCache" || error "Failed to remove UnityAdsVideoCache"
rm -f /sdcard/*.log && twk "Removed all log files" || error "Failed to remove log files"
rm -f /sdcard/*.CHK && twk "Removed all CHK files" || error "Failed to remove CHK files"
rm -rf /data/media/0/DCIM/.thumbnails && twk "Removed DCIM thumbnails" || error "Failed to remove DCIM thumbnails"
rm -rf /data/media/0/Pictures/.thumbnails && twk "Removed Pictures thumbnails" || error "Failed to remove Pictures thumbnails"
rm -rf /data/media/0/Music/.thumbnails && twk "Removed Music thumbnails" || error "Failed to remove Music thumbnails"
rm -rf /data/media/0/mtklog && twk "Successfully removed mtklog directory" || error "Failed to remove mtklog directory"

#######################################################

msg ""
msg "#######################################################"
msg " Deleting thermal cache folder" # We do not found who create this script , but, big thanks, shoutout and credit to the person who made it
if rm -f /data/vendor/thermal/config &&
   rm -f /data/vendor/thermal/thermal.dump &&
   rm -f /data/vendor/thermal/thermal_history.dump; then
    twk "Thermal files deleted successfully."
else
    error "Failed to delete thermal files."
fi

#######################################################

msg ""
msg "#######################################################"
msg " all done"
sleep 30
su -lp 2000 -c "cmd notification post -S bigtext -t 'Kaize Modulo' 'Tag' 'Status: Done'"