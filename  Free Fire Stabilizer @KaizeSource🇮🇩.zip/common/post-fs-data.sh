#!/system/bin/sh
MODDIR=${0%/*}
# # #  P o s t - f s - d a t a . s h  -  F r e e  F i r e  S t a b i l i z e r # # #
# Created By @KaizeSource a.k.a Kaize Team
# Published on Telegram on 13 - 2 - 2024



# Please Remember, always to give us a credit if you want to use our code.
# And also, if we do not found who made the script code that included in here, please let us know by dm-ing us so that we can correct it and give a credit to them.


# Kill Kernel Panic, Credit to @KaizeTeam
echo 0 > /proc/sys/kernel/panic
echo 0 > /proc/sys/kernel/panic_on_oops
echo 0 > /proc/sys/kernel/panic_on_warn
echo 0 > /sys/module/kernel/parameters/panic
echo 0 > /sys/module/kernel/parameters/panic_on_warn
echo 0 > /sys/module/kernel/parameters/pause_on_oops
echo 0 0 0 0 > /proc/sys/kernel/printk
echo off > /proc/sys/kernel/printk_devkmsg

# We do not found who create this script , but, big thanks, shoutout and credit to the person who made it
resetprop -n enable_blurs_on_windows 0
resetprop -n disableBlurs true
resetprop -n ro.sf.blurs_are_caro 1
resetprop -n ro.miui.has_real_blur 0
resetprop -n persist.sys.background_blur_supported false
resetprop -n ro.launcher.blur.appLaunch 0
resetprop -n ro.surface_flinger.supports_background_blur 0
resetprop -n ro.sf.blurs_are_expensive 0
resetprop -n persist.sys.sf.disable_blurs true

# Credur and big thanks to @eraselk for ngentouch code
resetprop -n touch.pressure.scale 0
resetprop -n touch.size.isSummed 0
resetprop -n view.touch_slop 3
resetprop -n TapInterval 1ms
resetprop -n TapDragInterval 1ms
resetprop -n QuietInterval 1ms
resetprop -n windowsmgr.max_events_per_sec 200
resetprop -n MultitouchMinDistance 1px
resetprop -n MultitouchSettleInterval 1ms
resetprop -n view.scroll_friction 0
resetprop -n ro.min_pointer_dur 0
resetprop -n touch.size.calibration geometric
resetprop -n touch.size.scale 1
resetprop -n touch.size.bias 0
resetprop -n touch.orientation.calibration interpolated
resetprop -n touch.distance.calibration area
resetprop -n touch.distance.scale 0
resetprop -n touch.coverage.calibration box
resetprop -n touch.gestureMode spots
resetprop -n touch.orientationAware 0
resetprop -n touch.pressure.calibration amplitude
resetprop -n ro.surface_flinger.max_frame_buffer_acquired_buffers 3
resetprop -n vendor.perf.gestureflingboost.enable true
resetprop -n persist.sys.scrollingcache 4
resetprop -n view.minimum_fling_velocity 10
resetprop -n ro.surface_flinger.set_touch_timer_ms 1
resetprop -n persist.vendor.qti.inputopts.movetouchslop 0.1
resetprop -n persist.vendor.qti.inputopts.enable true
resetprop -n debug.sf.hw 0
resetprop -n debug.hwui.skip_empty_damage true
resetprop -n debug.sf.high_fps_early_gl_phase_offset_ns 925000
resetprop -n ro.hwui.texture_cache_flush_rate 0.5
resetprop -n ro.hwui.layer_cache_flush_rate 0.5
resetprop -n ro.hwui.path_cache_flush_rate 0.5

# Disable GMS, Credit to @KaizeTeam
pm disable com.google.android.gms/com.google.android.gms.analytics.service.AnalyticsService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsTaskService
pm disable com.google.android.gms/com.google.android.gms.analytics.internal.PlayLogReportingService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsReceiver